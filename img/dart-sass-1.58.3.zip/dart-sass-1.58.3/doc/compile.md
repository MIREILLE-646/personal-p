APIs for compiling Sass source files to CSS, and providing options for that
compilation.

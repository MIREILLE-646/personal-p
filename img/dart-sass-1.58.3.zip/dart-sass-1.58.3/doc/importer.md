Classes for defining custom logic for resolving `@use`, `@forward`, and
`@import` rules in Sass. See [`Importer`] for details on the importer API
contract.

[`Importer`]: ../sass/Importer-class.html

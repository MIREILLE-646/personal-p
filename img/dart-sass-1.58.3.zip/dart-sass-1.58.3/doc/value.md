Classes that represent Sass values. These are passed to and returned by
user-defined [`Callable`]s that are passed to functions like
[`compileToResult()`].

[`Callable`]: ../sass/Callable-class.html
[`compileToResult()`]: ../sass/compileToResult.html

APIs for resolving dependencies between Sass files.

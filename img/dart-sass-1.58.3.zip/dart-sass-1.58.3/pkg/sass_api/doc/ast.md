Classes representing Sass's abstract syntax tree.

Certain AST classes, most notably [`Stylesheet`], have `parse()` constructors
that parse ASTs from string sources.

[`Stylesheet`]: ../sass/Stylesheet-class.html
